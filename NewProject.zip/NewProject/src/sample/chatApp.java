package sample;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class chatApp extends Application {
    private boolean isServer = true;
    private NetworkConnection connection = isServer ? createServer() : createClient();
    private TextArea messages = new TextArea();
    private Parent createContent(){
        messages.setPrefHeight(550);
        TextField input = new TextField();
        VBox root = new VBox(20, messages, input);
        root.setPrefSize(600, 600);
        connection.getData = input.toString();
        return root;
    }
    private Server createServer(){
        return new Server("127.0.0.1",2085,connection.getData.toString()+"\n");

    }
    private Client createClient(){
        return new Client("127.0.0.1",2085, connection.getData.toString()+"\n");
    }
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
         primaryStage.setScene(new Scene(createContent()));
         primaryStage.show();

    }
}
