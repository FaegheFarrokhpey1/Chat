package sample;

import javafx.scene.control.TextField;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public abstract class NetworkConnection {
    private connectionThread connThread = new connectionThread();
    public String getData = null;
    public NetworkConnection(String getData){
        this.getData = getData;
    }
    public void startConnection() throws Exception{
        connThread.start();
    }
    public void send(String Data) throws Exception{
        connThread.run();
    }
    public void closeConnection() throws Exception{
        connThread.serverSocket.close();
    }
    protected abstract boolean isServer();
    protected abstract String getIp();
    protected abstract int getPort();

    private class connectionThread extends Thread{
     protected ServerSocket serverSocket;
     protected Socket socket;
     protected ObjectOutputStream outputStream;
     protected ObjectInputStream inputStream;

        public void run(){
            try {
                 this.serverSocket = isServer() ? new ServerSocket(getPort()) : null;
                this.socket = isServer() ? serverSocket.accept() : new Socket(getIp(), getPort());
                this.outputStream = new ObjectOutputStream(socket.getOutputStream());
                this.inputStream = new ObjectInputStream(socket.getInputStream());
                TextField input = new TextField();
                while (true){
                    inputStream.readUTF();
                    outputStream.writeUTF(getData);
                }
            } catch (IOException e) {
                e.printStackTrace();

            }
        }
    }
}
