package ChatRoom;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaFX_Client extends Application {
    TextField textTitle;
    Label labelSys, labelIp, labelPort;
    TextField textIP;
    TextField textPort;
    Button ConnectButton;
    Button ClearButton;
    String title = "Client page";
    Label textResponse;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        labelSys = new Label("Please Enter Your Message:");
        textTitle = new TextField();
        textTitle.setPrefWidth(280);
        labelIp = new Label("IP Address:");
        textIP = new TextField();
        textIP.setPrefWidth(280);
        labelPort = new Label("Port ");
        textPort = new TextField();
        textPort.setPrefWidth(280);
        ConnectButton = new Button("Connect");
        ConnectButton.setPrefWidth(140);
        ClearButton = new Button("Clear");
        ClearButton.setPrefWidth(140);
        textResponse = new Label();

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(0, 0, 10, 10));
        gridPane.setAlignment(Pos.TOP_CENTER);

        gridPane.add(labelSys, 0, 0);

        gridPane.add(textTitle, 0, 1);

        gridPane.add(labelIp, 0, 3);

        gridPane.add(textIP, 0, 4);

        gridPane.add(labelPort, 0, 5);

        gridPane.add(textPort, 0, 6);

        gridPane.add(ConnectButton, 0, 7);

        gridPane.add(ClearButton, 1, 7, 1, 1);

        gridPane.add(textResponse, 0, 8);

        Scene scene = new Scene(gridPane, 300, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle(title);
        primaryStage.show();

        ConnectButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String TMsg = textTitle.getText();
                if (TMsg.equals("")) {
                    TMsg = null;
                }
                RunnableClient runnableClient = new RunnableClient(
                        textIP.getText(), Integer.parseInt(textPort.getText()), TMsg);
                new Thread(runnableClient).start();
            }
        });

    }

    class RunnableClient implements Runnable {

        String dstIP;
        int dstPort;
        String MsgToServer;
        String Response;

        public RunnableClient(String text, int parseInt, String tMsg) {
            this.dstIP = text;
            this.dstPort = parseInt;
            this.MsgToServer = tMsg;
        }

        @Override
        public void run() {
            Socket socket = null;
            DataInputStream dataInputStream = null;
            DataOutputStream dataOutputStream = null;
            try {
                socket = new Socket(dstIP, dstPort);
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataInputStream = new DataInputStream(socket.getInputStream());
                if (MsgToServer != null) {
                    dataOutputStream.writeUTF(MsgToServer);
                }
                Response = dataInputStream.readUTF();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {

                Platform.runLater(new Runnable() {

                    @Override
                    public void run() {
                        textResponse.setText(Response);
                    }
                });
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Client.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
}
