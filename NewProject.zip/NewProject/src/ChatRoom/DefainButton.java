package ChatRoom;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class DefainButton extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("GridPane Experiment");

        Button button1 = new Button("Button 1");
        button1.setPrefWidth(75);
        Button button2 = new Button("Button 2");
        button2.setPrefWidth(75);
        Button button3 = new Button("Button 3");
        button3.setPrefWidth(75);
        Button button4 = new Button("Button 4");
        button4.setPrefWidth(75);
        Button button5 = new Button("Button 5");
        button5.setPrefWidth(75);
        Button button6 = new Button("Button 6");
        button6.setPrefWidth(75);

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.TOP_CENTER);
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.add(button1, 0, 0, 1, 1);
        gridPane.add(button2, 1, 0, 1, 1);
        gridPane.add(button3, 2, 0, 1, 1);
        gridPane.add(button4, 0, 1, 1, 1);
        gridPane.add(button5, 1, 1, 1, 1);
        gridPane.add(button6, 2, 1, 1, 1);

        Scene scene = new Scene(gridPane, 280, 100);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
