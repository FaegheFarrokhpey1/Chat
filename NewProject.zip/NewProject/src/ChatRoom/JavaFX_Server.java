package ChatRoom;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaFX_Server extends Application {
    TextField textTitle;
    Label labelIp, labelPort;
    CheckBox optWelcome;
    Button sendText;
    Label Messages;
    public String Title  = "Server";
    String MessagesText = "";

    @Override
    public void start(Stage primaryStage) {

        textTitle = new TextField();
        textTitle.setPrefWidth(280);
        labelIp = new Label("192.168.0.1");
        labelPort = new Label();
        optWelcome = new CheckBox("Send Welcome when connect");
        optWelcome.setSelected(true);
        //sendText = new Button("Send Message");
        sendText.setPrefSize(280, 20);
        Messages = new Label();

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(0,0,10,10));
        gridPane.setVgap(20);

        gridPane.add(textTitle, 0 ,0,2,1);

        gridPane.add(labelIp, 0,1);

        gridPane.add(labelPort,0,2);

        gridPane.add(optWelcome, 0 ,3);

       // gridPane.add(sendText,0,4);

        gridPane.add(Messages, 0 ,4);

        Scene scene = new Scene(gridPane, 300, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle(this.Title);
        Thread socketServerThread = new Thread(new SocketServerThread());
        socketServerThread.setDaemon(true);
        socketServerThread.start();
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
    private class SocketServerThread extends Thread{
        static final int ServerSocketPort = 8080;
        int count = 0;
        public void run(){
            try {
                ServerSocket serverSocket = new ServerSocket(ServerSocketPort);
                Socket socket = null;
                Platform.runLater(new Runnable() {

                    @Override
                    public void run() {
                        labelPort.setText("I'm waiting Here: "+serverSocket.getLocalPort());
                    }
                });

                while (true) {
                    socket = serverSocket.accept();
                    count++;

                    //Start another thread
                    //to prevent blocked by empty dataInputStream
                    Thread acceptedThread = new Thread(
                            new ServerSocketAcceptedThread(socket, count));
                    acceptedThread.start();
                    acceptedThread.setDaemon(true); //terminate the thread when program end
                    acceptedThread.start();

                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    private class ServerSocketAcceptedThread extends Thread{
        Socket socket = null;
        int count = 0;
        DataInputStream dataInputStream;
        DataOutputStream dataOutputStream;

        public ServerSocketAcceptedThread(Socket socket, int count) {
            this.count = count;
            this.socket = socket;
        }

        public void run(){
            try {
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

                String MessageFromClient = dataInputStream.readUTF();
                 MessagesText += "#" + count +"\n"+ "Msg Client:"+ "\n"+ MessageFromClient;
                Platform.runLater(new Runnable() {

                    @Override
                    public void run() {
                        Messages.setText(MessagesText);
                    }
                });
                if(optWelcome.isSelected()){
                    String msgReply = "count: "+count + textTitle.getText();
                    try {
                        dataOutputStream.writeUTF(msgReply);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                if (dataInputStream != null) {
                    try {
                        dataInputStream.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                if (dataOutputStream != null) {
                    try {
                        dataOutputStream.close();
                    } catch (IOException ex) {
                        Logger.getLogger(Speaking.JavaFX_Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
    public String getIPAddress(){
        int ServerSocketPort = 8080;
        String Ip = labelIp.getText();

        return Ip;
    }
}
